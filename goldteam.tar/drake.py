'''new file'''

import importlib
import sys
from PyQt5 import QtWidgets, QtGui, QtCore

importlib.import_module("window")
importlib.import_module("encounter")

print("GOOD LUCK")


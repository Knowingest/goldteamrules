Harrison Hill hmh16
Dan Lukish dl16c
Ricardo Da Costa rad15j
Abigail Morrison afm15
Quinton Taylor qat

README

Intro:
Imagine this: you're tired of playing boring ol' triple A games. Such a large budget! 
So many options! Too much polish! You need an indie game. Scratch that, you need a game
made by average programmers that has an ass kicking female protagonist, some blobs to
attack, and a beautiful cave setting!
My friend, you have come to the right place!

Details:
Input is handled through terminal, except for the screen changes, those are done with
button clicks on the beautifully implemented backgrounds and scenery. Other than that, 
it's fairly self explanatory.
Fights are engaged when entering a new area. Terminal shows the enemies avalable to attack.
Inner dialogue is presented on new area entry, it shows what our heroine "Ilia" is thinking!
We only used PyQT for buttons and activation of said buttons, and random was imported
for certain enemy attacks and stats. 
No other resources were used that don't include documentation for Python/builtins, PyQT
and class notes. Most people would have probably used PyGame, since it's the most complete
way to actually make a game using Python, but we felt the sheer ammount of help and
information and built ins made the project obsolete or at least would be in bad spirit for
a *programming* class.

Seperation of Work:
Abigail -> ALL the sprite work (hella cool!) also worked on GUI implementation and laid 
out the outline of all the areas and how general flow of game. Worked with Ricardo to 
implement button+button functionality. 

Harrison -> Singlehandedly designed enemy controller and battle/terminal. Also designed 
and perfected most of the interface for the enemies and GUI, such as how damage got handled, 
how enemies were taken are of. Really helpful resource on discord for help when others got stuck. 

Ricardo Da Costa -> Helped Harrison and Abigail! Was in charge of emails, the readme (hi!)
and generally had his hands on most things. Also ended up reformatting and reworking the
enemy information, and implementing most of the button+button funtionality on the printed 
game screen.

Dan Lukish -> Worked on enemy information initially. Saved the day by helping Ricardo and
Abigail while they interally screamed at the compiler, worked a lot of details in at crunch
time to save functionality. Such as flushing more info into interface and teaching Ricardo
how to use more console commands and E X P E D I T E the process.

Quinton Taylor -> Worked on enemy information second. Brought many interesting ideas forward.
Generally kept team entertained.